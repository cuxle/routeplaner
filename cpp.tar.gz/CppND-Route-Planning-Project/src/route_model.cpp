#include "route_model.h"
#include <iostream>

RouteModel::RouteModel(const std::vector<std::byte> &xml) : Model(xml) {
    int counter = 0;
    for  ( Model::Node node : this->Nodes() ) {
        m_Nodes.push_back(Node(counter, this, node));
        counter++;
    }
    CreateNodeToRoadHashmap();
}

void RouteModel::CreateNodeToRoadHashmap()
{
    for( const Model::Road &road : Roads() ) {
        if ( road.type != Model::Road::Type::Footway ) {
            for( int node_idx : Ways()[road.way].nodes ) {
                if (node_to_road.find(node_idx) == node_to_road.end() ) {
                    node_to_road[node_idx] = std::vector<const Model::Road*>(); //what do this code do indeed                    
                }
                node_to_road[node_idx].push_back(&road);
            }
        }
    }
}

RouteModel::Node * RouteModel::Node::FindNeighbor(std::vector<int> node_indices)
{
    Node *closet_node = nullptr;
    Node node;
    for ( auto node_idx : node_indices ) {
        node = parent_model->SNodes()[node_idx];
        if (  distance(node) != 0 && !node.visited ) {
            if ( closet_node == nullptr || distance(node) < distance(*closet_node) ) {
                //这里引用了一个临时变量的地址，导致程序运行时崩溃，要特别注意
                closet_node = &(parent_model->SNodes()[node_idx]);
            }
        }
    }
    return closet_node;
}
//find this node's neighbors and push them in the neighbors member
//every node is on a few roads
//for every road find the neighbor
void RouteModel::Node::FindNeighbors()
{
    for ( auto &road : parent_model->node_to_road[this->index] ) {
        RouteModel::Node * node = FindNeighbor(parent_model->Ways()[road->way].nodes);
        if ( node ) {
            this->neighbors.push_back(node);
        }
    }


}

RouteModel::Node & RouteModel::FindClosestNode(float x, float y)
{
    Node node;
    node.x = x;
    node.y = y;

    float min_dist = std::numeric_limits<float>::max();
    int closest_idx = 0;
    for ( auto road : Roads() ) {
        if ( road.type != Model::Road::Type::Footway ) {
            for ( auto node_idx : Ways()[road.way].nodes ) {
                //if the distance is less than the min_dist, update the min_dist and the closest_idx;
                float dist = node.distance(SNodes()[node_idx]);
                if ( min_dist > dist ) {
                    min_dist = dist;
                    closest_idx = node_idx;
                }
            }
        }  
    } 

    return SNodes()[closest_idx];
}
