#ifndef ROUTE_MODEL_H
#define ROUTE_MODEL_H

#include <limits>
#include <cmath>
#include <unordered_map>
#include "model.h"
#include <iostream>
#include <vector>

class RouteModel : public Model {

  public:
    class Node : public Model::Node {
      public:
        // Add public Node variables and methods here.
        
        Node(){}
        Node(int idx, RouteModel * search_model, Model::Node node) : Model::Node(node), parent_model(search_model), index(idx) {}
        RouteModel::Node *parent = nullptr;
        float h_value = std::numeric_limits<float>::max(); //why this has to be initilist to a max float
        float g_value = 0.0;
        bool visited = false;
        std::vector<RouteModel::Node*> neighbors; 
        //float distance(Node node) const {std::sqrt((this->x - node.x)*(this->x - node.x)+(this->y - node.y)*(this->y - node.y));} 
        float distance(RouteModel::Node other) const {
          return std::sqrt( std::pow((this->x - other.x), 2) + std::pow((y - other.y), 2));
        }
        void FindNeighbors();       
      private:
        // Add private Node variables and methods here.
        RouteModel::Node * FindNeighbor(std::vector<int> node_indices);
        int index;
        RouteModel * parent_model = nullptr;
    };
    
    // Add public RouteModel variables and methods here.
    auto & GetNodeToRoadMap(){return node_to_road;}
    RouteModel::Node & FindClosestNode(float x, float y);
    RouteModel(const std::vector<std::byte> &xml);  
    std::vector<RouteModel::Node> &SNodes() {return m_Nodes;}
    std::vector<RouteModel::Node> path; // This variable will eventually store the path that is found by the A* search.


  private:
    // Add private RouteModel variables and methods here.
    std::vector<RouteModel::Node> m_Nodes;
    std::unordered_map<int,std::vector<const Model::Road*> > node_to_road;

    void CreateNodeToRoadHashmap();

};

#endif